package com.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 41;
    private static final int REQ_SPEECH = 42;
    private TextView status, heard;
    private Button talk;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private final int cyan = Color.rgb(0, 220, 255);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.rgb(3, 8, 22));
        getWindow().setNavigationBarColor(Color.rgb(3, 8, 22));
        buildUi();
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                int lang = tts.setLanguage(new Locale("pt", "BR"));
                tts.setPitch(0.72f);
                tts.setSpeechRate(0.88f);
                ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED;
                say("JARVIS iniciado. Aguardando seu comando, senhor.");
            }
        });
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
                public void onReadyForSpeech(Bundle b) { status.setText("OUVINDO..."); }
                public void onBeginningOfSpeech() { status.setText("ESCUTANDO SUA VOZ"); }
                public void onRmsChanged(float r) {} public void onBufferReceived(byte[] b) {}
                public void onEndOfSpeech() { status.setText("PROCESSANDO..."); }
                public void onError(int e) { status.setText("TOQUE PARA TENTAR NOVAMENTE"); }
                public void onResults(Bundle b) {
                    ArrayList<String> a = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (a != null && !a.isEmpty()) { heard.setText("VOCÊ: " + a.get(0)); answer(a.get(0)); }
                    status.setText("JARVIS ONLINE"); talk.setEnabled(true);
                }
                public void onPartialResults(Bundle b) {} public void onEvent(int t, Bundle b) {}
            });
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER); root.setPadding(28, 28, 28, 28); root.setBackgroundColor(Color.rgb(3, 8, 22));
        TextView title = new TextView(this); title.setText("J.A.R.V.I.S."); title.setTextColor(cyan); title.setTextSize(32); title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); title.setGravity(Gravity.CENTER);
        TextView sub = new TextView(this); sub.setText("JUST A RATHER VERY INTELLIGENT SYSTEM"); sub.setTextColor(Color.rgb(130,190,220)); sub.setTextSize(10); sub.setGravity(Gravity.CENTER);
        TextView orb = new TextView(this); orb.setText("◉"); orb.setTextColor(cyan); orb.setTextSize(104); orb.setGravity(Gravity.CENTER);
        status = new TextView(this); status.setText("INICIALIZANDO SISTEMAS..."); status.setTextColor(cyan); status.setTextSize(14); status.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); status.setGravity(Gravity.CENTER);
        heard = new TextView(this); heard.setText("Aguardando comando de voz."); heard.setTextColor(Color.WHITE); heard.setTextSize(16); heard.setGravity(Gravity.CENTER); heard.setPadding(8, 26, 8, 26);
        talk = new Button(this); talk.setText("FALAR COM JARVIS"); talk.setTextSize(16); talk.setTextColor(Color.BLACK); talk.setAllCaps(false); talk.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(cyan); bg.setCornerRadius(60); talk.setBackground(bg);
        talk.setOnClickListener(v -> startListening());
        TextView foot = new TextView(this); foot.setText("SISTEMA PESSOAL • VERSÃO 1.0"); foot.setTextColor(Color.rgb(75,115,145)); foot.setTextSize(10); foot.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2)); root.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(-1, 0, 1); root.addView(orb, op);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2)); root.addView(heard, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 58); bp.setMargins(0, 10, 0, 36); root.addView(talk, bp); root.addView(foot, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void startListening() {
        if (recognizer == null) { say("O reconhecimento de voz não está disponível neste aparelho."); return; }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
        }
        talk.setEnabled(false);
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga seu comando para o JARVIS");
        recognizer.startListening(i);
    }

    private void answer(String raw) {
        String q = raw.toLowerCase(Locale.ROOT); String r;
        if (q.contains("que horas") || q.contains("hora")) r = "Agora são " + new SimpleDateFormat("HH:mm", new Locale("pt", "BR")).format(new Date()) + ".";
        else if (q.contains("que dia") || q.contains("data")) r = "Hoje é " + new SimpleDateFormat("EEEE, d 'de' MMMM", new Locale("pt", "BR")).format(new Date()) + ".";
        else if (q.contains("abrir youtube")) { r = "Abrindo o YouTube."; openUrl("https://m.youtube.com"); }
        else if (q.contains("abrir google") || q.contains("pesquisar")) { r = "Abrindo a pesquisa do Google."; openUrl("https://www.google.com"); }
        else if (q.contains("quem é você") || q.contains("seu nome")) r = "Sou JARVIS, seu assistente pessoal. Sistemas operacionais.";
        else if (q.contains("obrigado") || q.contains("obrigada")) r = "Sempre à disposição, senhor.";
        else r = "Comando recebido: " + raw + ". Ainda estou aprendendo novos recursos. Posso informar as horas, a data ou abrir o YouTube e o Google.";
        heard.setText("JARVIS: " + r); say(r);
    }
    private void openUrl(String u) { try { startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(u))); } catch (Exception ignored) {} }
    private void say(String s) { if (ttsReady) tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis"); }
    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) { super.onRequestPermissionsResult(r,p,g); if (r == REQ_AUDIO && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) status.setText("JARVIS ONLINE"); }
    @Override protected void onDestroy() { if (recognizer != null) recognizer.destroy(); if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
